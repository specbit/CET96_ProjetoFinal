﻿namespace CET96_ProjetoFinal.web.Models
{
    public class PlatformAdminCondoViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public bool IsActive { get; set; }
        public string ManagerEmail { get; set; }
    }
}