﻿namespace CET96_ProjetoFinal.web.Entities
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
